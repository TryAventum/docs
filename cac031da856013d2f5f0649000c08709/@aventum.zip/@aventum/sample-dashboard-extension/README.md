# Aventum Sample Dashboard Extension(Final Build)

This extension for learning purpose only, it allows you to take an idea about how the final build of your extension should look like to create Aventum extension for the dashboard(the web app) of Aventum.

This extension will add **Sample Extension** section with tow items to the sidebar.